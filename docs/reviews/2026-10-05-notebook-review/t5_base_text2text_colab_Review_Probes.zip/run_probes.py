"""T5B review probes (torch-free; needs rouge-score). Usage: python run_probes.py <repo checkout> <out dir>"""
import json, os, sys, types, re, csv, io, importlib
from pathlib import Path

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/t5_base_text2text_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
PKG = 't5_base_text2text_pipeline'
S = importlib.import_module(PKG + '.samples'); M = importlib.import_module(PKG + '.metrics')
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
alltext = '\n'.join(src(i) for i in range(len(cells)))
pipe_src = (repo / f'src/{PKG}/pipeline.py').read_text()
md = [i for i, c in enumerate(cells) if c['cell_type'] == 'markdown']
R['P1_static'] = {'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3), 'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'asserts': [(i, l.strip()) for i in code if i not in (5, 7, 9) for l in src(i).splitlines() if l.strip().startswith('assert ')],
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'adapt_best_state_cloned_from_live_model': 'best_state = {k: v.detach().clone() for k, v in model.state_dict().items() if k in wanted}' in pipe_src,
    'epoch0_note_frozen_model': '"note": "frozen model"' in pipe_src,
    'doubled_braces_in_markdown': [(i, m) for i in md for m in re.findall(r'\{\{[^}]*\}\}', src(i))],
    'cell1_says_no_github_access': 'No GitHub access' in src(1), 'cell1_fetches_raw_githubusercontent': 'raw.githubusercontent.com' in src(1)}

# P2 fetch SciTLDR-A (pinned digests), rebuild split, leakage checks, Lead-1 baseline vs record and vs rouge-score
files = S.fetch_corpus(cache_dir=str(out / 'scitldr'))
corpus = S.read_corpus(files)
splits = S.build_sample_dataset(corpus, seed=42)
man = {k: S.validate_dataset(v) for k, v in splits.items()}
disj = S.check_split_disjoint(splits)
test = splits['test']
lead = M.lead_baseline(test, n_sentences=1)
norm = lambda s: re.sub(r'\W+', ' ', s.lower()).strip()
titles = {k: {norm(r['targets'][0]) for r in v} for k, v in splits.items()}
from rouge_score import rouge_scorer
sc = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=False)
hyp = [M.lead_sentences(r['source'], 1) for r in test]
rs = {k: 100 * sum(sc.score(r['targets'][0], h)[k].fmeasure for r, h in zip(test, hyp)) / len(test) for k in ('rouge1', 'rouge2', 'rougeL')}
sc2 = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
rs2 = {k: 100 * sum(sc2.score(r['targets'][0], h)[k].fmeasure for r, h in zip(test, hyp)) / len(test) for k in ('rouge1', 'rouge2', 'rougeL')}
R['P2_sample'] = {'raw_papers': {k: len(v) for k, v in corpus.items()}, 'file_bytes': {k: len(v) for k, v in files.items()},
    'splits': {k: m['n_records'] for k, m in man.items()}, 'disjoint': disj,
    'identical_titles_across_splits': {'train&test': len(titles['train'] & titles['test']), 'train&validation': len(titles['train'] & titles['validation']), 'validation&test': len(titles['validation'] & titles['test'])},
    'lead1_carried_metrics': {k: round(lead[k], 2) for k in ('rouge1', 'rouge2', 'rougeL', 'mean_output_words')},
    'lead1_recorded_kaggle': {'rouge1': 16.73, 'rouge2': 4.83, 'rougeL': 14.08, 'mean_output_words': 21.41},
    'lead1_rouge_score_0.1.2_no_stemmer': {k: round(v, 2) for k, v in rs.items()},
    'lead1_rouge_score_0.1.2_porter_stemmer': {k: round(v, 2) for k, v in rs2.items()}}

# P3 BYOD minimum and matrix through cell 13's sequence
def mk(n, fmt='csv', path=None, extra=None):
    rows = [{'id': f'r{i}', 'source': f'Document number {i} about topic {i % 7} with some words.', 'target': f'topic {i % 7} note {i}'} for i in range(n)]
    p = out / (path or f'byod_{n}.{fmt}')
    if fmt == 'csv':
        b = io.StringIO(); w = csv.DictWriter(b, fieldnames=['id', 'source', 'target']); w.writeheader(); w.writerows(rows); p.write_text(b.getvalue() + (extra or ''))
    elif fmt == 'jsonl':
        p.write_text('\n'.join(json.dumps(r) for r in rows))
    return p
def nb_byod(p):
    recs = S.load_byod_dataset(p); sp = S.split_dataset(recs, seed=42)
    m = {k: S.validate_dataset(v) for k, v in sp.items()}; S.check_split_disjoint(sp)
    return {k: x['n_records'] for k, x in m.items()}
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:200]}
smallest = next((n for n in range(8, 100) if run('n', lambda n=n: nb_byod(mk(n, path='scan.csv')))['verdict'] == 'accepted'), None)
cases = [
    run('60 rows CSV', lambda: nb_byod(mk(60))),
    run('60 rows JSONL', lambda: nb_byod(mk(60, 'jsonl'))),
    run('CSV with a prefixed source row', lambda: nb_byod(mk(60, path='pref.csv', extra='rx,summarize: some text here,ref\n'))),
    run('CSV with an empty target', lambda: nb_byod(mk(60, path='empt.csv', extra='ry,some text,\n'))),
    run('CSV with columns input,output', lambda: nb_byod((lambda p: (p.write_text('id,input,output\na,b,c\n'), p)[1])(out / 'cols.csv'))),
    run('empty CSV (header only)', lambda: nb_byod((lambda p: (p.write_text('id,source,target\n'), p)[1])(out / 'hdr.csv'))),
    run('Excel .xlsx', lambda: nb_byod((lambda p: (p.write_bytes(b'PK\x03\x04'), p)[1])(out / 'x.xlsx'))),
    run('CSV saved as UTF-8 with BOM', lambda: nb_byod((lambda p: (p.write_bytes(b'\xef\xbb\xbf' + mk(60, path='tmp.csv').read_bytes()), p)[1])(out / 'bom.csv'))),
]
R['P3_byod'] = {'stated_minimum': 'a dataset needs 8..20,000 records', 'smallest_accepted': smallest, 'matrix': cases}

# P4 upload branch of cell 13
c13 = src(13).replace('USE_BYOD = False', 'USE_BYOD = True'); head = c13.split('    records = load_byod_dataset')[0]
def exec_upload(up, colab=True):
    for k in ('google', 'google.colab'): sys.modules.pop(k, None)
    if colab:
        cm = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = cm; cm.files = types.SimpleNamespace(upload=lambda: up)
        sys.modules['google'] = g; sys.modules['google.colab'] = cm
    cwd = os.getcwd(); os.chdir(out)
    try:
        ns = {'Path': Path, 'os': os}; exec(compile(head, 'cell13', 'exec'), ns); return ns.get('file_name')
    finally: os.chdir(cwd)
R['P4_upload'] = {'cancelled': run('cancelled', lambda: exec_upload({})), 'two files': run('two', lambda: exec_upload({'a.csv': b'x', 'b.csv': b'y'})),
    'outside Colab': run('outside', lambda: exec_upload(None, colab=False)), 'has_path_field': bool(re.search(r'BYOD_(PATH|FILE)\s*=', src(13)))}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:8000])
